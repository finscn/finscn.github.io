#import <Foundation/Foundation.h>
#import "EJBindingBase.h"


@interface EJBindingLocalStorage : EJBindingBase {
}

@end
