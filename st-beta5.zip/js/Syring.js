

function Syring(cfg){
	EntityTemplate.movable(this);
	merger(this, cfg);
}

Syring.prototype={
	
	constructor : Syring ,
	
	defaultAnim : "idle",

	pin : {
		x : 130,
		y : 0,
		r : 8,
	},
	poly : [
		[-100,-19],
		[100,-19],
		[100,19],
		[-100,19]
	],



	rotation : 0,
	velR : 0 ,//-0.002,

	life : 5 ,
	score : 0,

	init : function(scene){
		this.scene=scene;
		this.anims={
			"idle" : createAnimation("syring-idle",{
							originX : 100,
							originY : 19
						})

		};

		var Me=this;
		this.anims.dieding=createAnimation("dieding",{
							onEnd : function(){
								Me.goHome();
							}
						})
		this.currentAnim=this.anims[this.defaultAnim];

		this.rotation=-0.5;

		this.currentPin=merger({},this.pin);
		this.currentPoly=clonePoly(this.poly);


		this.computeVelX(100,1000);
		this.computeVelY(150,300);

		this.defaultAccY = -this.accY;
		this.velX=0;
		this.velY=0;
		this.accY=0;
		
		this.reset();

	},

	checkHit : function(enemy){
		var Me=this;
		var dis=enemy.radius+this.currentPin.r;
		var dx=this.currentPin.x-enemy.x, dy=this.currentPin.y-enemy.y;

		if ( Math.pow(dx,2) + Math.pow(dy,2) <dis*dis){
			enemy.beKilled();
		}
	},

	update : function(timeStep){

		this.lastX=this.x;
		this.lastY=this.y;

		this.updateMovement(timeStep);
		this.updatePosition();


		this.rotation=this.rotation-this.velR*timeStep;
		
		if (this.flying){
			this.offsetX=this.offsetY=0;
			this.rx=this.x;
			this.ry=this.y;
			this.rotation = Math.atan2( this.velY, this.velX );
		}else{
		
			if (this.scene.touched){
				this.rotation=this.scene.gun.rotation;
			}

		}

		var cos=Math.cos(this.rotation),
			sin=Math.sin(this.rotation);
		
		if (!this.flying && this.scene.touched){
			this.x= this.rx+this.offsetX*cos-this.offsetY*sin;
			this.y= this.ry+this.offsetX*sin+this.offsetY*cos;
		}

		var op=this.poly;
		var Me=this;
		this.currentPoly.forEach(function(p,idx){
			p[0]=Me.x+op[idx][0]*cos-op[idx][1]*sin;
			p[1]=Me.y+op[idx][0]*sin+op[idx][1]*cos;
		});

		this.currentPin.x=this.x+this.pin.x*cos-this.pin.y*sin;
		this.currentPin.y=this.y+this.pin.x*sin+this.pin.y*cos;
		this.currentAnim.update(timeStep);

		if (this.x<0){
			if (this.life<=0 && this.scene.enemyCount>0){
				this.scene.lose=true;
			}else{
				this.reset();
			}
		}

	},

	dead : function(){
		if (!this.dieding){
			this.life--
			this.dieding=true;
			this.currentAnim=this.anims.dieding;
			this.velX=0;
			this.velY=0;
			this.accY=0; 
			this.scene.game.explodeSound.play();

		}
		// this.goHome();
	},

	fire : function(x,y,power){
		if (power<100){
			return;
		}
		power=power*0.002;
		var x=power*Math.cos(this.rotation);
		var y=power*Math.sin(this.rotation);

		this.velX=x;
		this.velY=y;
		this.accY=this.defaultAccY*0.12;
		this.flying=true;
		this.scene.game.fireSound.play();
	},

	goHome : function(){
		this.velX=-1;
		this.accY=0;
		this.velY=0;
		this.goingHome=true;
		this.currentAnim=this.anims.idle;
	},

	syncGun : function(cos,sin){

		

	},

	reset : function(){
		this.scene.gun.reset();
		this.offsetX=50;
		this.offsetY=-76;
		this.rx=this.scene.gun.x;
		this.ry=this.scene.gun.y;
		this.x=this.ox=this.rx+this.offsetX;
		this.y=this.oy=this.ry-this.offsetY;
		
		this.rotation=this.scene.gun.rotation;
		var cos=Math.cos(this.rotation),
			sin=Math.sin(this.rotation);
			
		this.x= this.rx+this.offsetX*cos-this.offsetY*sin;
		this.y= this.ry+this.offsetX*sin+this.offsetY*cos;

		this.velX=0;
		
		this.flying=false;
		this.goingHome=false;
		this.dieding=false;
	},

	render : function(context){
		if (this.goingHome){
			return;
		}

		context.save();
		context.translate(this.rx,this.ry);
		context.rotate(this.rotation);
		context.translate(this.offsetX,this.offsetY);

		context.translate(-this.currentAnim.originX,-this.currentAnim.originY);
		this.currentAnim.render(context);

		context.restore();

		// drawPoly(context, this.currentPoly,"red");

		// context.fillStyle="red";
		// context.fillRect(this.x-2,this.y-2,4,4);
		// var pin=this.currentPin;
		// context.beginPath();
		// context.arc( pin.x, pin.y, pin.r , 0,Math.PI*2, true);
		// context.fill();
		// context.closePath();

		if (this.lastLife!==this.life){
			this.scene.game.hud.setNodeValue("life",this.life);
			// this.scene.game.hud.setAttrValue("life",null,this.life);
			this.lastLife=this.life;
		}

		if (this.lastScore!==this.score){
			this.scene.game.hud.setNodeValue("score",this.score);
			this.lastScore=this.score;
		}

		// this.scene.game.hud.updateAllNodes(this);
	},

	handleInput : function(){

	}
};
