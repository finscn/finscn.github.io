
var Score = [

	{ score : 0, used : 0 , time : 0, star :0 },
	{ score : 0, used : 0 , time : 0, star :0 },
	{ score : 0, used : 0 , time : 0,star :0 },
	{ score : 0, used : 0 , time : 0,star :0 },
	{ score : 0, used : 0 , time : 0,star :0 }
]

function saveScore(){
	// console.log(JSON.stringify(Score));
	window.localStorage["st-score-1"]=JSON.stringify(Score);
}

function loadScore(){
	var score=window.localStorage["st-score-1"];
	Score=score?JSON.parse(score):Score;
	saveScore();
}
