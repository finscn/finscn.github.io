#import "EJBindingEventedBase.h"

@interface EJBindingAccelerometer : EJBindingEventedBase <UIAccelerometerDelegate>

@end
