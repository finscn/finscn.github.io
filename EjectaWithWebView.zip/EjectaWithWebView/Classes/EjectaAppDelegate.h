#import <UIKit/UIKit.h>
#import "EJApp.h"

@interface EjectaAppDelegate : NSObject <UIApplicationDelegate> {
	EJApp * app;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

