
function start() {
    var timeStep = 1000 / fps >> 0;
    audio.play();
    setInterval(function() {
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.drawImage(img, 100, 100);
    }, timeStep);

}
