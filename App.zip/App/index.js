var w = window.innerWidth;
var h = window.innerHeight;

var canvas = document.getElementById('canvas');
canvas.width = w;
canvas.height = h;
canvas.retinaResolutionEnabled = false;
var context = canvas.getContext('2d');
var fps = 60;


// create Interceptors. the Ejecta.DecryptorXOR is just an example.
// User could create any Interceptors by themselves ( must inherit EJBindingBaseInterceptor).

var decodeJS = new Ejecta.DecryptorXOR("afterLoadJS");
decodeJS.enable();

var decodeImage = new Ejecta.DecryptorXOR("afterLoadImage");
decodeImage.enable();

var decodeAudio = new Ejecta.DecryptorXOR("afterLoadAudio");
decodeAudio.enable();


//var filePath="original";
var filePath = "encrypted";

ejecta.include(filePath + "/main.js");

var img = new Image();
var audio = new Audio();


img.onload = function() {
    audio.loop = true;
    audio.src = filePath + "/big-audio.mp3";
    audio.load();
}
img.src = filePath + "/image.png";


// after img & audio loaded, start.
audio.addEventListener("canplaythrough", function() {
    start();
})
