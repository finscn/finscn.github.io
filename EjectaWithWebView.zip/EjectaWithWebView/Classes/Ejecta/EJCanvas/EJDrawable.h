#import <UIKit/UIKit.h>


@protocol EJDrawable

@property (readonly, nonatomic) EJTexture * texture;

@end
