# Encrypt files use :

node Encryptor.js  input-original-file  output-encryted-file
