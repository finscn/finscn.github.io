
var Classes={};

var SceneConfig={};

function registerScene(index,cfg){
	SceneConfig[index]=cfg;
}

function createScene(index){
	var cfg=SceneConfig[index];
	if (cfg){
		cfg=cloneSimple(cfg);
		var scene=newInstance(cfg,Scene);
		return scene;
	}
	return null;
}

function registerClass( classId, classDef ){
	Classes[classId]=classDef;
}

function newInstance(cfg,defaultClass){
	var classId=cfg.classId;
	var _class=Classes[classId]||defaultClass;
	return new _class(cfg);
}

var DEG_TO_RAD= Math.PI / 180;
var RAD_TO_DEG= 180 / Math.PI ;


function rotatePoly(poly,deg,cx,cy){
	cx=cx||0;
	cy=cy||0;
	var rad=deg*DEG_TO_RAD;
	var cos=Math.cos(rad), sin=Math.sin(rad);
	var len=poly.length;
	var poly2=[];
	for(var i = 0; i < len; i++){
		var p=poly[i];
		var px=p[0]-cx, py=p[1]-cy;
		var x= px*cos- py*sin;
		var y= px*sin+ py*cos;
		var p2=[ x+cx ,y+cy];
		poly2.push(p2);
	}
	return poly2;
}



function clonePoly(poly){
		var p=[];
		var len=poly.length;
		for(var i = 0; i < len; i++){
			p.push( [ poly[i][0], poly[i][1] ])
		}
		return p;
	}

function drawPoly(context,poly, color ,fill){
	var bak=context.strokeStyle;
	context.strokeStyle=color||bak;	
	context.beginPath();
	context.moveTo( poly[0][0] ,poly[0][1] );
	for (var i=0,len=poly.length;i<len;i++){
		var idx=(i+1)%len;	      		
		context.lineTo( poly[idx][0] ,poly[idx][1] );
	}
	if (fill){
		context.fillStyle=color||bak;	
		context.fill();
	}else{
		context.stroke();
	}	
	context.closePath();
	context.strokeStyle=bak;	
}

