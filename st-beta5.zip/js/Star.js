
function Star(cfg){
	merger(this, cfg);
}


Star.prototype={
	
	constructor : Star ,
	img : null,
	x : 0,
	y : 0,
	disabled : false ,
	
	init : function(scene){

		this.scene=scene;
		this.width=36;
		this.height=36;
		this.originX=42;
		this.originY=29;
		this.currentAnim=createAnimation("Item/star");

		this.hitBox=[this.x-this.width/2,this.y-this.height/2,
				this.x+this.width/2,this.y+this.height/2]

	},

	update : function(timeStep){
		this.currentAnim.x=this.x-this.originX;
		this.currentAnim.y=this.y-this.originY;
		this.currentAnim.update(timeStep);

	},

	isCollide : function(hitBox){
		return checkBoxCollide(this.hitBox, hitBox);
	},

	render : function(context,timeStep){
		this.currentAnim.render(context,timeStep);
		// context.strokeRect(this.hitBox.x1,this.hitBox.y1,this.width,this.height)
	}

}

