

function createUI(game){

	// game.uiManager=new DomUIManager({
	// 	uiPool: "ui-pool"
	// });
	// game.uiManager.init(game);

	
	
	// game.lifeBar=new DomUI({
	// 	id : "life-bar",
	// 	manager : game.uiManager,
	// 	init : function(){
	// 		this.dom=$id(this.id)
	// 		this.valueDom=this.dom.firstChild;
	// 	},
	// 	setValue : function(value){
	// 		this.valueDom.style.width=value*40+"px";
	// 	}
	// });
	// game.lifeBar.init();


	// game.timeBar=new DomUI({
	// 	id : "time-bar",
	// 	manager : game.uiManager,
	// 	init : function(){
	// 		this.dom=$id(this.id)
	// 		this.valueDom=this.dom.querySelector("span");
	// 	},
	// 	setValue : function(value){
	// 		this.valueDom.innerHTML=value;
	// 	}
	// });
	// game.timeBar.init();

	// game.scoreBar=new DomUI({
	// 	id : "score-bar",
	// 	manager : game.uiManager,
	// 	init : function(){
	// 		this.dom=$id(this.id)
	// 		this.valueDom=this.dom.querySelector("span");
	// 	},
	// 	setValue : function(value){
	// 		this.valueDom.innerHTML=value;
	// 	}
	// });
	// game.scoreBar.init();

	

}


(function(scope,undefined){


}(this));