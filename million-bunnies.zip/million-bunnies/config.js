var width = 900;
var height = 600;
// var fboSize = 1024 * 2;
var fboSize = 200;
var zoom = 1.0;
var bunniesToRender = 1000000 // 1048576 ;
var bunniesToRender = 16384 * 2;
