var IAPConfig = {

    "NoAD": {
        id: "FatFaces.NoAD",
        icon: "icon_noad",
        label: " No ADs",

        productName: "noAD",
        value: true,
        once: true,
    },

    "ManyCoins1": {
        id: "FatFaces.ManyCoins1",
        icon: "icon_coin",
        label: " x 200",

        productName: "coin",
        value: 200,
        add: true,
    },

    "ManyCoins2": {
        id: "FatFaces.ManyCoins2",
        icon: "icon_coin",
        label: " x 500",

        productName: "coin",
        value: 500,
        add: true,
    },

    "ManyCoins3": {
        id: "FatFaces.ManyCoins3",
        icon: "icon_coin",
        label: " x 2000",

        productName: "coin",
        value: 2000,
        add: true,
    },

};
