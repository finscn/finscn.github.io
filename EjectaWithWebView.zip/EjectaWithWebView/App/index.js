


//ejecta.require("./NativeRender.js");

ejecta.require("CallNative.js");

var webView = new Ejecta.WebView();
webView.src="index.html";

function check(){
    if (webView.loaded){
        webView.eval("thisIsAWebViewFunction();");
        return;
    }
    setTimeout(check,10);
}
check();

function thisIsAEjectJSFunction(){
    console.log("thisIsAEjectJSFunction called by WebView");
}