
function PopText(cfg){
	EntityTemplate.movable(this);
	merger(this, cfg);
}

PopText.prototype={
	
	constructor : PopText ,

	x : 0,
	y : 0,
	duration : 1000,
	
	alpha : 1.5 ,
	velA : 0,

	disabled : true,
	text : null,
	fontStyle : null,

	init : function(scene){

	},

	reset : function(){
		this.alpha=1.5;
		this.played=0;
		this.disabled=false;

		this.velX=0;
		this.velY=-150/this.duration;
		this.velA=-this.alpha/this.duration;
	},

	update : function(timeStep){
		if (this.disabled){
			return;
		}
		this.updateMovement(timeStep);
		this.updatePosition(timeStep);
		this.alpha=this.alpha+this.velA*timeStep;
		this.played+=timeStep;
		if (this.played>=this.duration){
			this.disabled=true;
		}

	},

	render : function(context){
		if (this.disabled || !this.text ){
			return;
		}
		context.save();
		context.globalAlpha=this.alpha;
		if (this.fontStyle){
			context.font=this.fontStyle;
		}
		if (this.color){
			context.fillStyle=this.color;
		}
		context.fillText(this.text, this.x, this.y);
		context.restore();
	}


}
