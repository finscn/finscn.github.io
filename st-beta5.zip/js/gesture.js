var Tap, Scroll,Scale, controller;

function initGesture(){

	Tap=Toucher.Listener.extend({
		
		lag : 800 ,
		limit : 8,
		enabled : false ,

		checkMoveArea : function(touchWrapper){
			var dx=Math.abs(touchWrapper.moveAmountX);
			var dy=Math.abs(touchWrapper.moveAmountY);

			return dx<=this.limit && dy<=this.limit;
		},
		checkEndTime : function(touchWrapper){
			return (touchWrapper.endTime-touchWrapper.startTime)<=this.lag;
		},

		start : function(wrappers,event,controller){
			this.enabled=wrappers.length==1;
			if (this.enabled){
				var x=wrappers[0].pageX;
				var y=wrappers[0].pageY;
				touchStartOnView(x,y);
			}

		},

		end : function(wrappers,event, controller){

			if (this.enabled && wrappers.length===1){
				//在屏幕上的手指是否在指定区域和时间范围内抬起,太迟了会视为无效tap
				if ( this.checkMoveArea(wrappers[0]) && this.checkEndTime(wrappers[0]) ){
					var x=wrappers[0].pageX;
					var y=wrappers[0].pageY;
					this.onTap(x,y,wrappers,event, controller);
				}
			}

			this.enabled=false;
		},


		/* Implement by user */
		filterWrapper : function(touchWrapper,event,controller){
           return controller.useMouse || event.changedTouches.length==1;
		},
		/* Implement by user */
		onTap : function(x,y,wrappers,event, controller){
			if (event.target.id!="hud"){
				return;
			}
			
		}

	});


	Scroll=Toucher.Listener.extend({

		start : function(wrappers,event,controller){
			
		},

		move : function(wrappers,event,controller){
			if (event.target.id!="hud"){
				return;
			}
			if (controller.useMouse|| event.touches.length==1){
				var dx=wrappers[0].deltaX;
				var dy=wrappers[0].deltaY;
				var sx=wrappers[0].startPageX;
				var sy=wrappers[0].startPageY;
				var x=wrappers[0].pageX;
				var y=wrappers[0].pageY;
				// if has actived building ,and start on building
				// drag building
				// TODO : 
				// else scroll view
				if (dx<-2||dx>2||dy<-2||dy>2){
					this.onScroll(dx,dy,x,y,sx,sy,wrappers,event,controller);
				}
			}
		},

		filterWrapper : function(touchWrapper,event,controller){
           return controller.useMouse || event.touches.length==1;
		},
		onScroll : function(dx,dy,x,y,sx,sy,wrappers,event,controller){
			// log(dx+","+dy);
			// scrollView(dx,dy,x,y,sx,sy);
		}


	});

	Scale=Toucher.Listener.extend({

		scale : 1 ,
		minScale : 0.5,
		maxScale : 2,
		move : function(wrappers,event,controller){

			if (game.isPlaying()&&!controller.useMouse && event.touches.length==2 && wrappers.length==2){
				var t1=wrappers[0], t2=wrappers[1];
				var disX= (t1.startPageX-t2.startPageX);
				var disY= (t1.startPageY-t2.startPageY);
				var dis=Math.sqrt(disX*disX+disY*disY);
				disX= (t1.pageX-t2.pageX);
				disY= (t1.pageY-t2.pageY);
				var newDis=Math.sqrt(disX*disX+disY*disY);
				var cx=(t1.pageX+t2.pageX)/2;
				var cy=(t1.pageY+t2.pageY)/2;
				var scale=newDis/dis;
				this.onScale(scale,cx,cy,wrappers,event,controller);
			}
			event.preventDefault();
		},
		start : function(wrappers,event,controller){
			if (game.isPlaying()){
				game.currentScene.beforeScale();
			}
		},
		end : function(wrappers,event,controller){

		},

		filterWrapper : function(touchWrapper,event,controller){
           return !controller.useMouse && event.touches.length==2;
		},
		onScale : function(scale,cx,cy,wrappers,event,controller){
			scale=Math.round(scale*50)/50;
			game.currentScene.scaleView(scale);
		}


	});

	controller=new Toucher.Controller({
		beforeInit : function(){
			this.dom=window;
			this.useMouse=!("ontouchstart" in window);
		},
		preventDefaultMove :true
	});

	controller.init();
	// controller.addListener(new Tap());
	// controller.addListener(new Scroll());
	controller.addListener(new Scale());


	/* element.classList.contains(className); */

}


