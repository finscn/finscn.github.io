

function Gun(cfg){
	merger(this, cfg);
}

Gun.prototype={
	
	constructor : Gun ,
	
	rotation : 0,

	x : 0,
	y : 0,
	offsetLeft : 0,
	offsetTop : 0,

	init : function(scene){
		this.scene=scene;

		this.img=ResourcePool.get("gun");

		this.reset();

		
	},

	reset : function(){
		this.rotation=-0.5;
		this.fired=false;
	},


	update : function(timeStep){
		
		if (!this.fired && this.scene.touched){
			var tx = this.scene.touchX ;
			var ty = this.scene.touchY ;
			var dx=tx - this.x;
			var dy=ty - this.y;
			this.rotation = Math.atan2( dy, dx );
			this.rotation=Math.min(0, Math.max(-1.4,this.rotation))
		}

	},


	fire : function(x,y,power){
		this.fired=true;

	},

	render : function(context){


		context.save();
		context.translate(this.x,this.y);
		context.rotate(this.rotation);
		context.translate(this.offsetLeft,this.offsetTop);

		context.drawImage(this.img,0,0);
		context.restore();

		// context.fillRect(this.x-16,this.y-16,36,36);
		// context.strokeRect(this.x-160,this.y-160,320,320);

	}
};
