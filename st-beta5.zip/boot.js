
var Config = {
	FPS : 45,
	width : 1024,
	height : 768-50,
	scale : 1 
}

var game=createGame();


window.onload=function(){

	var r= window.devicePixelRatio;
	
	r=r<2?1:r;

	// setViewportScale( 1/r );
	setTimeout(go,10);
	// go();

}
