
function Block(cfg){
	merger(this, cfg);
}

Block.prototype={
	
	constructor : Block ,

	x : 0 ,
	y : 0 ,
	w : 0 ,
	h : 0 ,
	// fix : 0.00001 ,
	fix : 0.005 ,
	
	img : null,//"ground",

	init : function(scene){
		this.scene=scene;
		this.img=ResourcePool.get(this.img)||this.img;

		this.aabb=calPolyAABB(this.polygon);
		this.x=this.aabb[0];
		this.y=this.aabb[1];
		this.w=this.aabb[2]-this.aabb[0];
		this.h=this.aabb[3]-this.aabb[1];
		this.hitBox={
			x1 : this.x ,
			y1 : this.y ,
			x2 : this.x+this.w ,
			y2 : this.y+this.h
		};
		this.offsetX=this.offsetX||0;
		this.offsetY=this.offsetY||0;

		this.hitBox.width=this.w;
		this.hitBox.height=this.h;

	},

	getHitBox : function(){
		return this.hitBox;
	},

	update : function(timeStep){
		return;
	
	},

	isCollidedPoint : function(x,y){
		var hitBox=this.hitBox;

		return x>=hitBox.x1 && x<=hitBox.x2
			&& y>=hitBox.y1 && y<=hitBox.y2;
	},

	render : function(context){

		if (this.destroyed){
			return 
		}
		// drawPoly(context,this.polygon,"red", !this.ground)

		var box=this.getHitBox();

		if (this.img){
			context.drawImage(this.img,0,0,
				this.img.width,
				this.img.height,
				box.x1+this.offsetX,box.y1+this.offsetY, 
				this.img.width,
				this.img.height );
		}
		// 	// context.drawImage(this.img,
		// 	// 	0,0,box.width,box.height,
		// 	// 	box.x1,box.y1,box.width,box.height);
	
		// }else{
			// context.fillStyle="#ff0000";
		// 	context.fillRect( box.x1,box.y1,box.width,box.height);
		// }
		context.strokeRect( box.x1,box.y1,box.width,box.height);
	}
}



