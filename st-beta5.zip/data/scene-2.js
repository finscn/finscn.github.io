
;(function(){

var cfg={

column:64,row:48,tileWidth:32,tileHeight:32,width:2048,height:1536,

enemyType : "enemy3-idle",


background : {
	bg : "lv3-bg",
	ground : "lv3-ground",
	items : [
		{img : "lv3-bg-0", x : 0, y : 1536-260 },
		{img : "lv3-bg-1", x : 500, y : 1536-600 },
	]},

baseArea : { x:0,y:1280,w:128,h:128 },

player : { x:0+100,y:1280+20  },

enemies : 
[
{ x:672,y:896,w:64,h:64 } , 
{ x:1056,y:928,w:64,h:64 },
{ x:1344,y:928,w:64,h:64 } , 
]
,

blocks : 
[

{ x:704,y:992,img:"lv3-b0",k:1,polygon:[[544,992],[672,992],[672,1408],[544,1408]] } , 
{ x:704,y:992,img:"lv3-b1",polygon:[[704,992],[864,992],[864,1408],[704,1408]] } , 
{ x:1024,y:960,img:"lv3-b2",k:2,polygon:[[1056,960],[1280,960],[1280,1120],[1056,1120]] } , 
{ x:1024,y:1120,img:"lv3-b3",polygon:[[1024,1120],[1312,1120],[1312,1408],[1024,1408]] },


{ x:1984-200,y:-9000,polygon:[[1984-200,-9000],[2048-200,-9000],[2048-200,1408],[1984-200,1408]] } , 
{ x:0,y:1408,ground:true,polygon:[[0,1408],[2048,1408],[2048,1536],[0,1536]] } , 
]

}

	registerScene(2,cfg);

}(this))

