
var inBrowser=false;
var quickplay=false;
function createGame(cfg){

	var game=new Game({
		container : "container",
		FPS : Config.FPS,
		width : Config.width,
		height : Config.height-(inBrowser?200:0),
		uiPool : "ui-pool",
		paused : false,
		resources : [

			{id : "syring-idle", src : "res/syring-idle.png"},
			{id : "power", src : "res/power.png"},
			{id : "enemy1", src : "res/enemy/enemy1.png"},
			{id : "enemy2", src : "res/enemy/enemy2.png"},
			{id : "enemy3", src : "res/enemy/enemy3.png"},
			{id : "enemy4", src : "res/enemy/enemy4.png"},
			{id : "smoke", src : "res/smoke.png"},
			{id : "gun", src : "res/gun.png"},
			{id : "stone", src : "res/stone.png"},
			{id : "pre", src : "res/levelmenu/bg.png" },

			{id : "lv1-bg", src : "res/lv1/bg.png"},
			{id : "lv2-bg", src : "res/lv2/bg.png"},
			{id : "lv3-bg", src : "res/lv3/bg.png"},
			{id : "lv4-bg", src : "res/lv4/bg.png"},
			// {id : "lv5-bg", src : "res/lv5/bg.png"},

			{id : "lv1-ground", src : "res/lv1/ground.png"},
			{id : "lv2-ground", src : "res/lv2/ground.png"},
			{id : "lv3-ground", src : "res/lv3/ground.png"},
			{id : "lv4-ground", src : "res/lv4/ground.png"},
			// {id : "lv5-ground", src : "res/lv5/ground.png"},

			{id : "lv1-bg-0", src : "res/lv1/bg-item-0.png"},
			{id : "lv1-bg-1", src : "res/lv1/bg-item-1.png"},
			{id : "lv2-bg-0", src : "res/lv2/bg-item-0.png"},
			{id : "lv2-bg-1", src : "res/lv2/bg-item-1.png"},
			{id : "lv3-bg-0", src : "res/lv3/bg-item-0.png"},
			{id : "lv3-bg-1", src : "res/lv3/bg-item-1.png"},
			{id : "lv4-bg-0", src : "res/lv4/bg-item-0.png"},
			{id : "lv4-bg-1", src : "res/lv4/bg-item-1.png"},
			// {id : "lv5-bg-0", src : "res/lv5/bg-item-0.png"},
			// {id : "lv5-bg-1", src : "res/lv5/bg-item-1.png"},


			{id : "lv1-b0", src : "res/lv1/b0.png" },
			{id : "lv1-b1", src : "res/lv1/b1.png" },
			{id : "lv1-b2", src : "res/lv1/b2.png" },

			{id : "lv2-b0", src : "res/lv2/b0.png" },
			{id : "lv2-b1", src : "res/lv2/b1.png" },
			{id : "lv2-b2", src : "res/lv2/b2.png" },
			{id : "lv2-b3", src : "res/lv2/b3.png" },
			{id : "lv2-b4", src : "res/lv2/b4.png" },
			{id : "lv2-b5", src : "res/lv2/b5.png" },

			{id : "lv3-b0", src : "res/lv3/b0.png" },
			{id : "lv3-b1", src : "res/lv3/b1.png" },
			{id : "lv3-b2", src : "res/lv3/b2.png" },
			{id : "lv3-b3", src : "res/lv3/b3.png" },


			{id : "lv-T", src : "res/lv4/T.png" },
			{id : "lv-C", src : "res/lv4/C.png" },
			{id : "lv-I", src : "res/lv4/I.png" },
			{id : "lv-U", src : "res/lv4/U.png" },

			// {id : "crack", type : "media", src : "res/crack.mp3"},
			// {id : "bgm", type : "media", loop:true, src : "res/bgm.mp3"},
		],
		
		loader : {
			paiallel : !true,
			delay : 0//1
		},

		initEvent : function(){
			var Me=this;
			this.fireSound=new Media("res/sound/fire.mp3");
			this.hitSound={
				index : 0,
				channel : [
					new Media("res/sound/explode.mp3"),
					new Media("res/sound/explode.mp3"),
					new Media("res/sound/explode.mp3"),
					new Media("res/sound/explode.mp3"),
					new Media("res/sound/explode.mp3")
				],
				play : function(){
					var idx=this.index%this.channel.length;
					this.channel[idx].play();
					this.index++
				}

			}

			this.explodeSound=new Media("res/sound/explode.mp3");

            this.titleSound = new Media("res/sound/title_theme.mp3", 
            	function(){
            		Me.titleSound.play();
           		}, 
           		function(){
            	
            	}, 
            	function(){

            	}
            );
			var Me=this;
			// var rect=this.pos;
			var rect={
				left : 0,
				top : 0
			};

		this.supportTouch = "ontouchstart" in document;
		var touchDown = false;

		var downEvent = "mousedown",
			upEvent = "mouseup",
			moveEvent = "mousemove";

		if (this.supportTouch) {
			downEvent = "touchstart";
			upEvent = "touchend";
			moveEvent = "touchmove";
		}
		window.addEventListener(downEvent, function(event) {
			touchDown = true;
			var x = this.supportTouch?event.changedTouches[0].pageX:event.pageX,
				y = this.supportTouch?event.changedTouches[0].pageY:event.pageY;
			var dx = x - rect.left,
				dy = y - rect.top;
			if (Me.currentScene) {
				Me.currentScene.touchDown(dx, dy);
			}
		});

		window.addEventListener(moveEvent, function(event) {
			if (touchDown) {
				var x = this.supportTouch?event.changedTouches[0].pageX:event.pageX,
					y = this.supportTouch?event.changedTouches[0].pageY:event.pageY;
				var dx = x - rect.left,
					dy = y - rect.top;
				if (Me.currentScene) {
					Me.currentScene.touchMove(dx, dy);
				}
			}
			event.preventDefault();

		});

		window.addEventListener(upEvent, function(event) {
			touchDown = false;
			var x = this.supportTouch?event.changedTouches[0].pageX:event.pageX,
				y = this.supportTouch?event.changedTouches[0].pageY:event.pageY;
			var dx = x - rect.left,
				dy = y - rect.top;
			if (Me.currentScene) {
				Me.currentScene.touchUp(dx, dy);
			}
		});


			window.addEventListener("keydown", function(event) {
				KeyState[event.keyCode] = true;
			}, true);

			window.addEventListener("keyup", function(event) {
				KeyState[event.keyCode] = false;
			}, true);

			initToucher();
			initGesture();

			// hideAddressBar();
		},
		onInit : function(){
			
		},
		isPlaying : function(){
			return this.currentScene && !this.paused;
		},
		onLoading: function(loadedCount, totalCount, res) {
			// console.log("loading : "+loadedCount+"/"+totalCount);
		},

		updateLevel : function(){
			var select=this.uiManager.getView("level-select")
			var lvs=document.querySelectorAll("#level-select .level");
			for (var i=0;i<lvs.length;i++){
				var lv=lvs[i];
				var s=Score[i].star;
				var starBar=lv.querySelector(".star-bar");
				starBar.style.width=s*30+"px"
				if (i>0){
					console.log(i-1,Score[i-1].star)
					if (Score[i-1].star<1){
						lv.classList.add("lv-lock");
					}else{
						lv.classList.remove("lv-lock");
					}					
				}
			}
		},
		initUI : function(){
			$id("main-menu").style.width=game.width+"px";
			$id("main-menu").style.height=game.height+"px";
			$id("level-menu").style.width=game.width+"px";
			$id("level-menu").style.height=game.height+"px";
			var Me=this;
			$id("item-next").onclick=function(event){
				game.currentScene.nextScene();
			};

        	loadScore();
        	this.updateLevel();


			$id("level-select").onclick=function(event){
				var lv=event.target;
				var id=lv.getAttribute("lv");
				if (id){
					id=Number(id);
					if (id>0){
						if (Score[id-1].star<1){
							return;
						}
					}
					Me.uiManager.hideUI("level-menu");
					Me.start(id);
				}
			}

			$id("start").onclick=function(){
				Me.uiManager.hideUI("main-menu");
				Me.uiManager.showUI("level-menu");
				loadScore();
	        	Me.updateLevel();

				// Me.start();
			}
			$id("item-restart").onclick=$id("item-restart-o").onclick=function(){
				game.paused=false;
				Me.uiManager.hideUI("pause-menu");					
				game.start(game.currentScene.index);
			}
			$id("item-back").onclick=$id("item-back-f").onclick=$id("item-back-o").onclick=function(){
				game.paused=true;
				Me.uiManager.hideUI("game-finish");					
				Me.uiManager.hideUI("pause-menu");					
				Me.uiManager.showUI("level-menu");
				loadScore();
	        	Me.updateLevel();

				// window.location.reload();
			}

			$id("item-resume").onclick=function(){
				game.paused=false;
				Me.uiManager.hideUI("pause-menu");					
								
			}

			$id("pause").onclick=function(){
				if (game.paused){
					game.paused=false;
					Me.uiManager.hideUI("pause-menu");					
				}else{
					game.paused=true;
					Me.uiManager.showUI("pause-menu");					
				}
			}

			this.hud=this.uiManager.getView("hud");
		},
		onReady : function(){
			// this.container.style.webkitTransformOrigin="left top";
			// this.container.style.webkitTransform="scale(0.5,0.5)";
			// this.canvas.style.backgroundColor="#ccddee";

			var Me=this;
			if (quickplay){
				Me.start(); return;
			}

			Me.titleSound.play();
			Me.uiManager.showUI("main-menu");

			// Me.uiManager.showUI("level-select");
			// Me.fpsCounter.reset();
		},

		getSceneInstance : function(index){
			var scene=createScene(index);
			return scene;
		},

		play : function(){
			this.start();		
			// this.fpsCounter.reset();
		},

		exit : function(){
			window.location.reload();
		},

		clear : function(){
			
		},

		afterLoop : function(){
			// this.fpsCounter.tick();
		}

	});
	return game;
}

function createAnimation(name,cfg){
	var _cfg=_animationPool[name]||{};
	_cfg=cloneSimple(_cfg);
	merger(_cfg,cfg);
	_cfg.img=ResourcePool.get(_cfg.img)||_cfg.img;
	return new Animation(_cfg);
}



function go(){
	if (go.called){
		return;
	}
	go.called=true;
	
	
	// setViewportScale( 1/2 );
	// setTimeout(function(){
	// 	showWindowSize();
	// 	setTimeout(function(){
	// 		setViewportScale( 1/2 );
	// 		setTimeout(function(){
	// 			showWindowSize();
	// 		},20)
	// 	},100)
	// },20)

	// game.fpsCounter.init();
	createUI(game);
	$id("hud").style.width=Config.width+"px";
	$id("hud").style.height=Config.height+"px";
	game.init();
	game.load();
}



