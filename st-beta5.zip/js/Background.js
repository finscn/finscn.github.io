
function Background(cfg){
	EntityTemplate.collidable(this);
	merger(this, cfg);
}


Background.prototype={
	
	constructor : Background ,

	init : function(scene){
		// return;
		this.scene=scene;
		this.game=scene.game;

		this.bg=ResourcePool.get(this.bg)
		this.ground=ResourcePool.get(this.ground);
		this.groundY=this.scene.height-120;

		this.items.forEach(function(item){
			item.img=ResourcePool.get(item.img);
			item.x=item.x||0;
			item.y=item.y||0;
			item.width=item.img.width;
			item.height=item.img.height;
		});

		this.viewWidth=scene.viewWidth;
		this.viewHeight=scene.viewHeight;

		this.viewport=scene.game.viewport;
		this.layers=this.layers||[];
		
		var z=5;
		var Me=this;
		this.layers.forEach(function(l){
			l.zIndex=z++;
			l.parentDom=Me.viewport;
			l.init(Me);
		});

	},
	beforeRun : function(){
		// this.game.viewport.style.backgroundImage="url("+this.bg.src+")";
	},

	update : function(timeStep){
		// return;
		this.x=this.scene.x;
		this.y=this.scene.y;
		this.layers.forEach(function(e){
			e.update(timeStep);
		})

	},
	renderBg : function(context){
		context.drawImage(this.bg,
			0,0,this.bg.width,this.bg.height,
			0,0,this.viewWidth,this.viewHeight);
	},

	render : function(context,timeStep){
		

		this.items.forEach(function(item,idx){
			context.drawImage(item.img, item.x, item.y);
			if (idx===0){
				context.drawImage(item.img, item.x+item.img.width, item.y);
			}	
		});

		var bx=Math.floor(this.scene.x);
		var by=Math.floor(this.scene.y);
		var ox=bx%this.ground.width;
		var width=this.scene.viewWidth/this.scene.scale;
		var cols=Math.ceil(width/this.ground.width)+4;
		for (var c=0;c<cols;c++){
			context.drawImage(this.ground, -ox+c*this.ground.width,this.groundY);	
		}

		// return;
		this.layers.forEach(function(e){
			e.render(context,timeStep);
		})
	}

}
