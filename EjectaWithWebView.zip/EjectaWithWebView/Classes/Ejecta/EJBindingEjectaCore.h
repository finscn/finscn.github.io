#import <Foundation/Foundation.h>
#import "EJBindingBase.h"

@interface EJBindingEjectaCore : EJBindingBase {
	NSString * urlToOpen;
}

@end
