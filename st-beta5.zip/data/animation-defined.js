var _animationPool={

	"syring-idle" : {
		img : "syring-idle", 
		loop : true, 
		frames : [
			{x : 0, y : 0, w : 234, h : 38, d : 9E9 },
		]
	},
	"enemy1-idle" : {
		img : "enemy1", 
		loop : true, 
		originX : 55,
		originY : 66,
		frames : [
			{x : 0, y : 0, w : 110, h : 132, d : 200 }		]
	},
	"enemy2-idle" : {
		img : "enemy2", 
		loop : true, 
		originX : 70,
		originY : 55,
		frames : [
			{x : 0, y : 0, w : 173, h : 104, d : 200 }		]
	},
	"enemy3-idle" : {
		img : "enemy3", 
		loop : true, 
		originX : 70,
		originY : 50,
		frames : [
			{x : 0, y : 0, w : 189, h : 93, d : 200 }		]
	},
	"enemy4-idle" : {
		img : "enemy4", 
		loop : true, 
		originX : 64,
		originY : 64,
		frames : [
			{x : 0, y : 0, w : 194, h : 142, d : 200 }		]
	},
	"dieding" : {
		img : "smoke" ,
		loop : true, 
		width : 96, 
		height : 96, 
		originX : 48,
		originY : 72,
		frames : [
			{ x : 0, y : 0, d : 100},
			{ x : 1*96, y : 0, d : 100},
			{ x : 2*96, y : 0, d : 100},
			{ x : 3*96, y : 0, d : 100}
		]
	}

};