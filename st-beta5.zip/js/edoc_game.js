// =============== console for WebView ==================

var ARGUMENT_SEPARATOR = ":EDOC:"

var console = window.console || {};

console.send = function (command_word, args) {
    var iframe = document.createElement("iframe");
    var command_arr = ["command", command_word].concat(args);    
    iframe.setAttribute("src", command_arr.join(ARGUMENT_SEPARATOR));
    document.body.appendChild(iframe);
    iframe.parentNode.removeChild(iframe);
    iframe = null;
}

console.nativeLog = function (msg) {
    console.send("log", [msg]);
}

console.update = function (index, total) {
    console.send("update_page_index", [index, total]);
}

console.submit = function (data, special_type) {
    console.send("submit_data", [data, special_type]);
}

function Media(src, mediaSuccess, mediaError, mediaStatus) {
    var self = this;

    var call_native_audio = function () {
        var args = [].slice.apply(arguments);

        args.unshift(self.id);

        console.send("audio", args);
    }

    var get_new_key = function (obj) {
        var id_num = 1;
        while("id_" + id_num in obj)
            id_num++;
        return "id_" + id_num;
    }

    this.src = src;
    this.callbacks = {
        mediaSuccess: mediaSuccess,
        mediaError: mediaError,
        mediaStatus: mediaStatus
    };

    this.id = get_new_key(EDoc.native_objects);

    EDoc.native_objects[this.id] = this;

    self.position = 0;

    self.play = function () { call_native_audio("play"); };

    self.pause = function () { call_native_audio("pause"); };

    self.resume = function () { call_native_audio("resume"); };

    self.stop = function () { call_native_audio("stop"); };

    self.seekTo = function (pos) { call_native_audio("seek_to", pos / 1000); };

    self.getDuration = function () { return self.duration; };

    self.getCurrentPosition = function (mediaSuccess, mediaError) {
        var new_callback_id = get_new_key(self.callbacks);
        self.callbacks[new_callback_id] = mediaSuccess;
        call_native_audio("get_current_position", new_callback_id);
    };

    console.send("audio", [this.id, "create", src]);
}

Media.MEDIA_NONE = 0;
Media.MEDIA_STARTING = 1;
Media.MEDIA_RUNNING = 2;
Media.MEDIA_PAUSED = 3;
Media.MEDIA_STOPPED = 4;

var EDoc = (function () {
    // =================Main======================

    function main() {
    }

    return {
        main: main,
        native_objects: {},
    };
})();

