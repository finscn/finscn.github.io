

function Enemy(cfg){
	EntityTemplate.movable(this);
	merger(this, cfg);
}

Enemy.prototype={
	
	constructor : Enemy ,

	defaultAnim : "idle",
		

	rotation : 0,

	x : 0,
	y : 0,

	radius : 65,

	init : function(scene){
		this.scene=scene;

		this.anims=this.anims||{
			"idle" : createAnimation(scene.enemyType||"enemy1-idle",{
							
						})

		};
		var Me=this;
		this.anims.dieding=createAnimation("dieding",{
							onEnd : function(){
								Me.dead=true;
							}
						})

		this.currentAnim=this.anims[this.defaultAnim];
		// console.log(this.currentAnim.img)
		
		this.ox=this.x;
		this.oy=this.y;


	},


	reset : function(x,y){		
		this.x=this.ox;
		this.y=this.oy;
		this.currentAnim=this.anims[this.defaultAnim];
	},

	beKilled : function(){
		this.dieding=true;
		this.currentAnim=this.anims.dieding
		this.scene.game.hitSound.play();
		this.scene.showPopText("+10",this.x,this.y);
		this.scene.player.score+=10;
	},

	update : function(timeStep){

		this.lastX=this.x;
		this.lastY=this.y;

		this.currentAnim.update(timeStep);
		// this.collBlock();
	},
		

	render : function(context){

		if (this.dead){
			return;
		}
		context.save();
		context.translate(this.x,this.y);
		context.rotate(this.rotation);

		context.translate(-this.currentAnim.originX,-this.currentAnim.originY-6);
		this.currentAnim.render(context);

		context.restore();

		context.beginPath();
		context.strokeStyle="red";
		context.arc( this.x , this.y , this.radius , 0,Math.PI*2, true);
		context.stroke();
		context.closePath();

	}


};
