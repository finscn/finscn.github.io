
function Scene(cfg){
	merger(this, cfg);
}

Scene.prototype={
	
	constructor : Scene ,

	index : 0,

	x : 0,
	y : 0,
	width : 320,
	height : 320,

	player : null ,
	background : null ,

	maxEnemyCount : Infinity,
	enemyCount : 0,

	enemies : null ,
	popTexts : null ,
	items : null ,
	ui : null ,

	baseArea : {
		x : 0,
		y : 0,
		w : 100,
		h : 100,
	},

	scale : 1 ,

	init: function(game) {
		this.game=game;

		this.viewWidth=game.viewWidth;
		this.viewHeight=game.viewHeight;

		// this.trigger=new Trigger({
		// 	game : game,
		// 	scene : this
		// });
		this.powerImg=ResourcePool.get("power");


		this.tempBox=[];
		this._collInfo={collidedX:[],collidedY:[]};

		this.camera=new Camera({
			x : 0,
			y : 0,
			width : this.viewWidth,
			height : this.viewHeight,
			minX : 0,
			minY : this.viewHeight,
			maxX : this.width-this.viewWidth+1,
			maxY : this.height-this.viewHeight+1
		});
		this.camera.setPadding(200,200,900,200);

		this.gun=new Gun({
			x : 100 ,
			y : this.height-180,
			offsetLeft : -65,
			offsetTop : -93
		})
		this.gun.init(this);
		

		this.background=this.createBackground();
		this.popTexts=this.createPopTexts();
		this.player=this.createPlayer();
		this.enemies=this.createEnemies();
		this.blocks=this.createBlocks();
		
		this.enemyCount=this.enemies.length;

		this.camera.focus(this.player);
		this.x=this.camera.x;
		this.y=this.camera.y;

		this.onInit();
		this.scaleView(0.6)

	},

	onInit : function(){

	},
	scaleView : function(scale){
		// return;
		this.scale=Config.scale*scale;

		this.scale=Math.max(0.5,Math.min(1,this.scale));

		this.camera.width=this.camera.oWidth/this.scale;
		this.camera.height=this.camera.oHeight/this.scale;
		this.camera.top=this.oTop/this.scale;
		this.camera.right=this.oRight/this.scale;
		this.camera.bottom=this.oBottom/this.scale;
		this.camera.left=this.oLeft/this.scale;
		// this.camera.maxX = this.width-this.viewWidth+1;
		// this.camera.maxY = this.height-this.viewHeight+1

// 		this.camera.maxX = Math.max(0,this.width-this.viewWidth/this.scale);
// 		this.camera.maxY = Math.max(0,this.height-this.viewHeight/this.scale)+200;
// 		this.camera.minY = this.camera.maxY-10;
// console.log(this.camera.minY)
		var dx=0;
		var dy=this.height;
		dx/=this.scale;
		dy/=this.scale;
		this.x=0-dx;
		this.y=this.height-dy;
		this.camera.x=this.x;
		this.camera.y=this.y;
	},

	beforeScale : function (){
		Config.scale=this.scale;
	},



	beforeRun : function(){

		this.showHUD();

		this.background.beforeRun();

		this.frameCount=0;
		// this.bgm=ResourcePool.get("bgm");
		// if (this.bgm){
		// 	this.bgm.volume=0;
		// 	this.bgm.play();
		// }
		// this.crack=new SoundPool();
		// if (this.crack){
		// 	// this.crack.volume=0;
		// 	this.crack.init(ResourcePool.get("crack"),3);
		// }
		
	},

	showHUD : function(){
		this.game.uiManager.showUI("hud");
		this.game.uiManager.hideUI("pause-menu");
		this.game.uiManager.hideUI("clear-menu");
		this.game.uiManager.hideUI("game-over");

	},

	fixTouchXY : function(x,y){
		// x=Math.max(150,x);
		// y=Math.min(500,y);
		x/=this.scale;
		x+=this.x;

		y=this.viewHeight-y
		y/=this.scale;
		y=this.height-y

		this.touchX=x;
		this.touchY=y;
	},

	touchedGun : function(){
		var dx=Math.abs(this.touchX-this.gun.x);
		var dy=Math.abs(this.touchY-this.gun.y);
		// alert([dx,dy])
		return dx<=240 && dy<=240;
	},
	touchDownTime: 0,
	touchDown: function(x, y) {
		if (this.player.flying) {
			return;
		}
		this.fixTouchXY(x,y);
		if ( !this.touchedGun() ){
			return;
		}
		this.touchDownX = this.touchX;
		this.touchDownY = this.touchY;
		this.touched = true;
		this.touchDownTime = Date.now();

		this.power=0;
	},

	touchMove: function(x, y) {
		
		if (this.player.flying) {
			return;
		}
		if (this.touched ) {
			this.fixTouchXY(x,y);

			var px = this.touchX - this.player.x;
			var py = this.touchY - this.player.y;
			this.power = Math.sqrt(Math.pow(px, 2) + Math.pow(py, 2));
			this.power = Math.min(640,this.power);
		}
	},

	touchUp: function(x, y) {
		if (this.player.flying || !this.touchDownTime) {
			return;
		}
		this.fixTouchXY(x,y);
		this.touchUpX = this.touchX;
		this.touchUpY = this.touchY;
		this.touched = false;
		this.touchDownTime = 0;

		this.player.fire(this.touchX, this.touchY, this.power);
		this.power=0;
	},

	update: function(timeStep) {
		this.frameCount++;

		if (this.finished){
			this.finish();
			return;
		}
		if (this.lose){
			this.gameover();
			return;
		}
        
		var game=this.game;
		timeStep=game.timeStep;
		timeStep=Math.min(timeStep,game.maxTimeStep);
       
		// this.trigger.update(timeStep);
		var player=this.player;
		var enemies=this.enemies;
		var Me=this;

		this.background.update(timeStep);

		var scene=this;

		this.gun.update(timeStep);

		var down=player.velY>0;
		player.update(timeStep);
		

		this.popTexts.forEach(function(e){
			e.update(timeStep);
		});

		//if (!this.scrollByTouch && player.flying){
			this.camera.focus(player);
		//}
		this.x=this.camera.x;
		this.y=this.camera.y;

		var rSq=Math.pow(player.pin.r,2);
		var deadEnemy=0;
		enemies.forEach(function(e){
			if (e.dead){
				deadEnemy++;
				return;
			}
			e.update(timeStep);
			if (!e.dieding && !player.dieding && !player.goingHome){
				player.checkHit(e);
			}

		})

		this.blocks.some(function(b,idx){
			if (b.destroyed){
				return false;
			}
			if (!player.dieding && checkPointInPoly(player.currentPin.x,player.currentPin.y,b.polygon)
				|| checkPolyCollide(player.currentPoly,b.polygon)){
				player.dead();
				if ( "k" in b){
					var eidx=b.k-1;
					var enemy=enemies[eidx];
					if (enemy){
						enemy.beKilled();
					}
					b.destroyed=true;
				}
				return true;
			}
		})

		if (deadEnemy==this.enemyCount){
			this.finished=true;
		}

	},

	clear : function(context, timeStep){
		// context.clearRect(0,0,this.viewWidth,this.viewHeight);
	},

	render: function(context, timeStep) {

		// return;

		this.clear(context, timeStep);

		this.background.renderBg(context,timeStep);
		
		context.save();

		context.translate(-this.x,-this.y-60);

		context.translate(0,this.height);
		context.scale(this.scale,this.scale)
		context.translate(-0,-this.height);

		this.background.render(context,timeStep);

		this.popTexts.forEach(function(e){
			e.render(context,timeStep);
		});

		this.gun.render(context,timeStep);
		// this.renderGun(context);
		this.player.render(context,timeStep);

		this.blocks.forEach(function(e){
			if (e.hp===0){
				return;
			}
			e.render(context,timeStep);
		});
		
		this.enemies.forEach(function(e){
			e.render(context,timeStep);
		});

		// context.fillRect(this.touchX,this.touchY, 20,20)

		if (this.touched){
			this.renderPower(context);
		}

		context.restore();
		


		// if (this.player.fireable){
		// 	this.fireButton.style.backgroundColor="#ff0000";
		// }else{
		// 	this.fireButton.style.backgroundColor="#999999";
		// }
	},

	renderPower :function(context){
		context.save();
		context.strokeStyle="red"
		context.translate(this.player.x,this.player.y);
		context.rotate(this.player.rotation);
		// context.strokeRect(0,-25,10+this.power,50);
		var l=Math.min(160,this.power*0.25);
		context.globalAlpha=0.7;
		context.drawImage(this.powerImg,0,0,160,45, 120,-25,160,45);
		context.drawImage(this.powerImg,160,0,l,45, 120,-25,l,45);

		context.restore();
	},

	afterLoop : function(timeStep){
		
	},
	handleInput : function(timeStep){
		
		var n=KeyState[Key.N];
		var g=KeyState[Key.G];
		var f=KeyState[Key.F];
		if (n){
			KeyState[Key.N]=false;
			this.finish();
			return;
		}
		if (g){
			KeyState[Key.G]=false;
			this.gameover();
			return;
		}
		if (f){
			KeyState[Key.F]=false;
			this.gamefinish();
			return;
		}
		this.player.handleInput(timeStep);

	},
	finish : function(){
		var used=5-this.player.life;
		var star=Math.max(1,this.player.life+1);
		console.log(star);
		if (star>Score[this.index].star){
			Score[this.index].star=star;
		}
		saveScore();
		this.game.paused=true;
		this.game.uiManager.showUI("clear-menu");
		star=Math.min(star,3);
		$id("clear-menu").setAttribute("star", ""+star);
		// $id("clear-menu").star=""+star;
	},
	gameover : function(){
		this.game.paused=true;
		this.game.uiManager.showUI("game-over");

	},
	gamefinish : function(){
		this.game.paused=true;
		this.game.uiManager.showUI("game-finish");
	},

	nextScene : function(){
		this.game.uiManager.hideUI("clear-menu");
		var ni=++this.index;
		var t=this.game.start(ni);
		if (t===false){
			this.game.uiManager.showUI("game-finish");
		}
		this.game.paused=false;

	},

	createBackground : function(){
		var obj=newInstance( this.background, Background );
		obj.init(this);
		return obj;
	},
	createPlayer : function(){
		var obj=newInstance( this.player, Syring );
		obj.init(this);
		return obj;
	},

	createPopTexts : function(){
		var scene=this;
		var list=[];
		this.popTexts=this.popTexts||[
			{color : "#ff6633", fontStyle : "40pt foo" },
			{color : "#ff6633", fontStyle : "40pt foo" },
			{color : "#ff6633", fontStyle : "40pt foo" },
			{color : "#ff6633", fontStyle : "40pt foo" },
			{color : "#ff6633", fontStyle : "40pt foo" },

		];
		this.popTexts.forEach(function(e){
			var obj=newInstance(e, PopText) ;
			obj.init(scene);
			list.push( obj)
		})

		return list;
	},


	createEnemies : function(){
		var scene=this;
		var list=[];
		this.enemies=this.enemies||[];
		this.enemies.forEach(function(e,idx){
			e=e||{};
			scene.enemies[idx]=e;

			var obj=newInstance(e, Enemy) ;
			obj.init(scene);
			list.push( obj);
		})

		return list;
	},

	createBlocks : function(){
		var scene=this;
		var list=[];
		this.blocks=this.blocks||[];
		this.blocks.forEach(function(e){
			var obj=newInstance(e, Block) ;
			obj.init(scene);
			list.push( obj)
		})

		return list;
	},


	popTextIndex : 0,
	showPopText : function(text, x ,y){
		var pop=this.popTexts[this.popTextIndex];
		this.popTextIndex=(++this.popTextIndex)%this.popTexts.length;
		pop.x=x;
		pop.y=y;
		pop.text=text;
		pop.reset();
	}

}





